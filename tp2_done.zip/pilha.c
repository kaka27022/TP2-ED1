#include "pilha.h"
#include "labirinto.h"

#include <stdio.h>
#include <stdlib.h>

struct labirinto{

  char **lab;
  int lins;
  int cols;
};

// ================================================================================= -[INIT]- ==============================================================================================

Coordenadas firstPos(Labirinto *labirinto) {
    Coordenadas pos;
    for (int i = 0; i < labirinto->lins; i++) {
        for(int j = 0; j < labirinto->cols; j++) {
            if (labirinto->lab[i][j] == 'M') {
                pos.x = i;
                pos.y = j;
            }
        }
    }

    return pos;
}
// ================================================================================ [ OPERAÇÕES: PILHA ] ===================================================================================
//                                                                                                                                                                    BUSCA EM PROFUNDIDADE 

int caminhoValido(Labirinto *labirinto, int lins, int cols) {
    return (labirinto->lab[lins][cols] == ' ');
}

void iniciaPilha(Pilha *pilha) {
    pilha->cabeca = NULL;
    pilha->topo = NULL;
    pilha->tamanho = 0;
}

int pilhaEhVazia(Pilha *pilha) {
    return (pilha->tamanho == 0);
}


// [ADICIONA UM ELEMENTO AO TOPO] -- NOTA: "topo" não faz parte da lista, é como um clone;
void pilhaPush(Pilha *pilha, Coordenadas pos) {
    Celula2 *new = (Celula2*)malloc(sizeof(Celula2));
    if (new == NULL)
        printf("\nmemória insuficiente!!\n");

    new->item = pos;
    new->prox = NULL;
    pilha->tamanho++;

    if (pilha->cabeca == NULL) {
        pilha->topo = new;
        pilha->cabeca = new;
    } else {
        pilha->topo->prox = new;
        pilha->topo = new;
    }
}

// [RETIRA O ELEMENTO DO TOPO]
Coordenadas pilhaPop(Pilha *pilha) {
    Coordenadas pilhaVazia;
    pilhaVazia.x = -1; pilhaVazia.y = -1;
    if (pilhaEhVazia(pilha))
        return pilhaVazia;
    Celula2 *aux = pilha->cabeca;
    Coordenadas removed = pilha->topo->item;

    if (pilha->tamanho > 2) 
        while (aux->prox->prox != NULL) // para qdo estver uma posição anterior ao topo
            aux = aux->prox;
    
    pilha->tamanho--;
    free(pilha->topo);
    if (pilha->tamanho > 0) {
        aux->prox = NULL;
        pilha->topo = aux;
    } else {
        pilha->topo = NULL;
        pilha->cabeca = NULL;
    }

    return removed;
}

int contapassos(Labirinto *labirinto) {
    int cont = 0;
    for (int i = 0; i < labirinto->lins; i++)
        for (int j = 0; j < labirinto->cols; j++)
            if (labirinto->lab[i][j] == 'o')
                cont++;

    return cont;
}

void printLab(Labirinto *labirinto) {
    printf("\n%d\n", contapassos(labirinto));
    for (int i = 0; i < labirinto->lins; i++) {
        for (int j = 0; j < labirinto->cols; j++) {
            printf("%c", labirinto->lab[i][j]);
        }
        printf("\n");
    }
}

void desalocarPilha(Pilha *pilha) {
    Celula2 *aux = pilha->cabeca;
    if (pilha->tamanho > 1) {
        Celula2 *aux2 = pilha->cabeca->prox;
        while(aux2 != NULL) {
            free(aux);
            aux = aux2;
            aux2 = aux2->prox;
        }
    } else if (pilha->tamanho == 1) {
        free(aux);
    }

    free(pilha);
}

int acharSaidaPilha(Labirinto *labirinto) {
    int visitado[labirinto->lins][labirinto->cols];
    Pilha *pilha = malloc(sizeof(Pilha));
    iniciaPilha(pilha);
    Coordenadas pos = firstPos(labirinto);
    Coordenadas posaux = pos;
    
    // marcando tudo como nao visitado
    for (int i = 0; i < labirinto->lins; i++)
        for (int j = 0; j < labirinto->cols; j++)
            if (labirinto->lab[i][j] == ' ')
                visitado[i][j] = 0;
    pilhaPush(pilha, pos);

    while(!pilhaEhVazia(pilha)) {
        visitado[pos.x][pos.y] = 1;
        if (pos.x != posaux.x || pos.y != posaux.y)
            labirinto->lab[pos.x][pos.y] = 'o';
        
        // [DIREITA]
        if (!(visitado[pos.x][pos.y + 1]) && (caminhoValido(labirinto, pos.x, pos.y + 1))) {
            pos.y++; 
            pilhaPush(pilha, pos);
        }
        // [BAIXO]
        else if (!(visitado[pos.x + 1][pos.y]) && (caminhoValido(labirinto, pos.x + 1, pos.y))) {
            pos.x++; 
            pilhaPush(pilha, pos);
        }
        // [ESQUERDA]
        else if (!(visitado[pos.x][pos.y - 1]) && (caminhoValido(labirinto, pos.x, pos.y - 1))) {
            pos.y--; 
            pilhaPush(pilha, pos);
        }
        // [CIMA]
        else if (!(visitado[pos.x - 1][pos.y]) && (caminhoValido(labirinto, pos.x - 1, pos.y))) {
            pos.x--; 
            pilhaPush(pilha, pos);
        }
        else {
            pos = pilhaPop(pilha);
        }
    }
    if (labirinto->lab[labirinto->lins - 2][labirinto->cols - 1] == 'o') {
        printLab(labirinto);
        desalocarPilha(pilha);
            
        return 1;
    }

    printLab(labirinto);
    desalocarPilha(pilha);
    return 0;
}
