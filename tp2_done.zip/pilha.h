#ifndef PILHA_H
#define PILHA_H
#include "fila.h"
#include "labirinto.h"

typedef struct labirinto Labirinto;

typedef struct celula2 {
    Coordenadas item;
    struct celula2 *prox;
} Celula2;

typedef struct {
    int tamanho;
    Celula2 *topo;
    Celula2 *cabeca;
} Pilha;




// [ALOCAÇÃO x INICIALIZAÇÃO]
void printLab(Labirinto *);
Coordenadas firstPos(Labirinto*);

int pilhaEhVazia(Pilha*);
void iniciaPilha(Pilha*);
Coordenadas pilhaPop(Pilha*);
int acharSaidaPilha(Labirinto*);
void pilhaPush(Pilha*, Coordenadas);

// [OPERAÇÕES DA PILHA]
int contapassos(Labirinto*);

// [DESALOCAÇÃO x FIM]
void desalocarPilha(Pilha*);           

#endif // LABIRINTO_H